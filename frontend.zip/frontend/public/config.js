// 运行时的全局配置文件
// 在部署时，可以通过修改此文件来改变前端连接的后端地址，而无需重新打包
window.__DORA_RUNTIME_CONFIG__ = {
  NEXT_PUBLIC_API_URL: "https://artbackend.horaart.com/api/v1",
  NEXT_BRAND_NAME: "Hora Art",
  NEXT_TOP_LEFT_LOGO_WITH_BRAND: false,
  NEXT_SOURCE_API_URL: "https://app.horaart.com",
  NEXT_PROJECT_ID: "2047256638200483840",
  NEXT_USE_REMOTE_I18N: true, // 是否使用远程的国际化配置，为 false 时使用本地语言文件
  NEXT_CONFIG_LANGUAGE_ZH: "2049064123840335872",
  NEXT_CONFIG_LANGUAGE_EN: "2049063828129320960",
  NEXT_CONFIG_LANGUAGE_ZH_HANS: "2049063954331734016",
  NEXT_ICP_RECORD_NUMBER: "",
  IS_PAY_ENABLED: false,
}
