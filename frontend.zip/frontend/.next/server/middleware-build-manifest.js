globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/baAHqylI7dF6t6S3edqcE/_buildManifest.js",
    "static/baAHqylI7dF6t6S3edqcE/_ssgManifest.js",
    "static/baAHqylI7dF6t6S3edqcE/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/05~q..z0qnnbd.js",
    "static/chunks/0acq.3lyl4w8~.js",
    "static/chunks/0e_eyiice5y5h.js",
    "static/chunks/13p0h5faqtus9.js",
    "static/chunks/turbopack-01xi25yztm~7f.js"
  ]
};
