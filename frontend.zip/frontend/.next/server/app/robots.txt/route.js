var R=require("../../chunks/[turbopack]_runtime.js")("server/app/robots.txt/route.js")
R.c("server/chunks/[root-of-the-server]__0a345us._.js")
R.c("server/chunks/[root-of-the-server]__0gqq2tp._.js")
R.c("server/chunks/_next-internal_server_app_robots_txt_route_actions_0o-41u5.js")
R.m(97131)
module.exports=R.m(97131).exports
