1:"$Sreact.fragment"
3:I[98877,["/_next/static/chunks/0-a~.zjh.4es-.js","/_next/static/chunks/0yc4e27uxqth5.js","/_next/static/chunks/0565375x.yve~.js","/_next/static/chunks/0krq79ixq3i3-.js","/_next/static/chunks/0zu3am009s7rg.js"],"default"]
4:I[95566,["/_next/static/chunks/0-a~.zjh.4es-.js","/_next/static/chunks/0yc4e27uxqth5.js","/_next/static/chunks/0565375x.yve~.js","/_next/static/chunks/0krq79ixq3i3-.js","/_next/static/chunks/0zu3am009s7rg.js"],"default"]
5:I[90522,["/_next/static/chunks/0-a~.zjh.4es-.js","/_next/static/chunks/0yc4e27uxqth5.js","/_next/static/chunks/0565375x.yve~.js","/_next/static/chunks/0krq79ixq3i3-.js","/_next/static/chunks/0zu3am009s7rg.js"],"OutletBoundary"]
6:"$Sreact.suspense"
9:I[90522,["/_next/static/chunks/0-a~.zjh.4es-.js","/_next/static/chunks/0yc4e27uxqth5.js","/_next/static/chunks/0565375x.yve~.js","/_next/static/chunks/0krq79ixq3i3-.js","/_next/static/chunks/0zu3am009s7rg.js"],"ViewportBoundary"]
b:I[90522,["/_next/static/chunks/0-a~.zjh.4es-.js","/_next/static/chunks/0yc4e27uxqth5.js","/_next/static/chunks/0565375x.yve~.js","/_next/static/chunks/0krq79ixq3i3-.js","/_next/static/chunks/0zu3am009s7rg.js"],"MetadataBoundary"]
d:I[70028,["/_next/static/chunks/0-a~.zjh.4es-.js","/_next/static/chunks/0yc4e27uxqth5.js","/_next/static/chunks/0565375x.yve~.js","/_next/static/chunks/0krq79ixq3i3-.js","/_next/static/chunks/0zu3am009s7rg.js"],"default",1]
:HL["/_next/static/chunks/041cvacqxa3ip.css","style"]
0:{"P":null,"c":["","_not-found"],"q":"","i":false,"f":[[["",{"children":["/_not-found",{"children":["__PAGE__",{}]}]},"$undefined","$undefined",16],[["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/041cvacqxa3ip.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}],["$","script","script-0",{"src":"/_next/static/chunks/0-a~.zjh.4es-.js","async":true,"nonce":"$undefined"}],["$","script","script-1",{"src":"/_next/static/chunks/0yc4e27uxqth5.js","async":true,"nonce":"$undefined"}],["$","script","script-2",{"src":"/_next/static/chunks/0565375x.yve~.js","async":true,"nonce":"$undefined"}],["$","script","script-3",{"src":"/_next/static/chunks/0krq79ixq3i3-.js","async":true,"nonce":"$undefined"}],["$","script","script-4",{"src":"/_next/static/chunks/0zu3am009s7rg.js","async":true,"nonce":"$undefined"}]],"$L2"]}],{"children":[["$","$1","c",{"children":[null,["$","$L3",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L4",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":"$undefined","forbidden":"$undefined","unauthorized":"$undefined"}]]}],{"children":[["$","$1","c",{"children":[[["$","title",null,{"children":"404: This page could not be found."}],["$","div",null,{"style":{"fontFamily":"system-ui,\"Segoe UI\",Roboto,Helvetica,Arial,sans-serif,\"Apple Color Emoji\",\"Segoe UI Emoji\"","height":"100vh","textAlign":"center","display":"flex","flexDirection":"column","alignItems":"center","justifyContent":"center"},"children":["$","div",null,{"children":[["$","style",null,{"dangerouslySetInnerHTML":{"__html":"body{color:#000;background:#fff;margin:0}.next-error-h1{border-right:1px solid rgba(0,0,0,.3)}@media (prefers-color-scheme:dark){body{color:#fff;background:#000}.next-error-h1{border-right:1px solid rgba(255,255,255,.3)}}"}}],["$","h1",null,{"className":"next-error-h1","style":{"display":"inline-block","margin":"0 20px 0 0","padding":"0 23px 0 0","fontSize":24,"fontWeight":500,"verticalAlign":"top","lineHeight":"49px"},"children":404}],["$","div",null,{"style":{"display":"inline-block"},"children":["$","h2",null,{"style":{"fontSize":14,"fontWeight":400,"lineHeight":"49px","margin":0},"children":"This page could not be found."}]}]]}]}]],null,["$","$L5",null,{"children":["$","$6",null,{"name":"Next.MetadataOutlet","children":"$@7"}]}]]}],{},null,false,null]},null,false,"$@8"]},null,false,null],["$","$1","h",{"children":[["$","meta",null,{"name":"robots","content":"noindex"}],["$","$L9",null,{"children":"$La"}],["$","div",null,{"hidden":true,"children":["$","$Lb",null,{"children":["$","$6",null,{"name":"Next.Metadata","children":"$Lc"}]}]}],null]}],false]],"m":"$undefined","G":["$d",[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/041cvacqxa3ip.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}]]],"S":true,"h":null,"s":"$undefined","l":"$undefined","p":"$undefined","d":"$undefined","b":"baAHqylI7dF6t6S3edqcE"}
e:[]
8:"$We"
a:[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]
f:I[97987,["/_next/static/chunks/0-a~.zjh.4es-.js","/_next/static/chunks/0yc4e27uxqth5.js","/_next/static/chunks/0565375x.yve~.js","/_next/static/chunks/0krq79ixq3i3-.js","/_next/static/chunks/0zu3am009s7rg.js"],""]
11:I[9975,["/_next/static/chunks/0-a~.zjh.4es-.js","/_next/static/chunks/0yc4e27uxqth5.js","/_next/static/chunks/0565375x.yve~.js","/_next/static/chunks/0krq79ixq3i3-.js","/_next/static/chunks/0zu3am009s7rg.js"],"I18nProvider"]
12:I[80809,["/_next/static/chunks/0-a~.zjh.4es-.js","/_next/static/chunks/0yc4e27uxqth5.js","/_next/static/chunks/0565375x.yve~.js","/_next/static/chunks/0krq79ixq3i3-.js","/_next/static/chunks/0zu3am009s7rg.js"],"ToastProvider"]
13:I[62836,["/_next/static/chunks/0-a~.zjh.4es-.js","/_next/static/chunks/0yc4e27uxqth5.js","/_next/static/chunks/0565375x.yve~.js","/_next/static/chunks/0krq79ixq3i3-.js","/_next/static/chunks/0zu3am009s7rg.js"],"IconMark"]
10:T814,
(() => {
  if (typeof window === "undefined") return;

  const url = new URL(window.location.href);
  const ticket = url.searchParams.get("ticket");
  if (!ticket) return;

  const pendingKey = "__dora_ticket_login_pending__";
  const clearStoredAuth = () => {
    window.localStorage.removeItem("token");
    window.localStorage.removeItem("user");
  };

  window.sessionStorage.setItem(pendingKey, "1");

  const cleanTicketFromUrl = () => {
    url.searchParams.delete("ticket");
    return url.toString();
  };

  // ticket 登录优先于本地残留登录态，先清空再进行单点登录。
  clearStoredAuth();

  const apiBaseURL =
    (window.__DORA_RUNTIME_CONFIG__ && window.__DORA_RUNTIME_CONFIG__.NEXT_PUBLIC_API_URL) ||
    "http://localhost:6444/api/v1";

  fetch(apiBaseURL.replace(/\/$/, "") + "/login/ticket", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ ticket }),
  })
    .then(async (response) => {
      const result = await response.json().catch(() => null);
      if (!response.ok) {
        const message = result && (result.msg || result.message || result.error);
        throw new Error(message || "ticket login failed");
      }

      const payload = (result && result.data) || result;
      if (!payload || !payload.user || !payload.token) {
        throw new Error("ticket login payload is invalid");
      }

      const token =
        typeof payload.token === "string" ? payload.token : payload.token.access_token;
      if (!token) {
        throw new Error("access token missing");
      }

      window.localStorage.setItem("token", token);
      window.localStorage.setItem("user", JSON.stringify(payload.user));
      window.sessionStorage.removeItem(pendingKey);

      const nextUrl = cleanTicketFromUrl();
      if (url.pathname === "/login") {
        window.location.replace(url.origin + "/");
        return;
      }
      window.location.replace(nextUrl);
    })
    .catch(() => {
      window.sessionStorage.removeItem(pendingKey);
    });
})();
2:["$","html",null,{"lang":"zh-CN","children":["$","body",null,{"className":"h-screen overflow-hidden antialiased","children":[["$","$Lf",null,{"src":"/config.js","strategy":"beforeInteractive"}],["$","$Lf",null,{"id":"ticket-login-bootstrap","strategy":"beforeInteractive","dangerouslySetInnerHTML":{"__html":"$10"}}],["$","$L11",null,{"initialBrandConfig":{"brandName":"Dora Art","brandTitle":"Dora Art"},"children":["$","$L12",null,{"children":["$","div",null,{"className":"relative z-10 h-full min-h-0 overflow-hidden","children":["$","$L3",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L4",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":[[["$","title",null,{"children":"404: This page could not be found."}],["$","div",null,{"style":"$0:f:0:1:1:children:1:children:0:props:children:0:1:props:style","children":["$","div",null,{"children":[["$","style",null,{"dangerouslySetInnerHTML":{"__html":"body{color:#000;background:#fff;margin:0}.next-error-h1{border-right:1px solid rgba(0,0,0,.3)}@media (prefers-color-scheme:dark){body{color:#fff;background:#000}.next-error-h1{border-right:1px solid rgba(255,255,255,.3)}}"}}],["$","h1",null,{"className":"next-error-h1","style":"$0:f:0:1:1:children:1:children:0:props:children:0:1:props:children:props:children:1:props:style","children":404}],["$","div",null,{"style":"$0:f:0:1:1:children:1:children:0:props:children:0:1:props:children:props:children:2:props:style","children":["$","h2",null,{"style":"$0:f:0:1:1:children:1:children:0:props:children:0:1:props:children:props:children:2:props:children:props:style","children":"This page could not be found."}]}]]}]}]],[]],"forbidden":"$undefined","unauthorized":"$undefined"}]}]}]}]]}]}]
7:null
c:[["$","title","0",{"children":"短剧制作 - 一站式智能短剧制作平台 | doraArt Pro"}],["$","meta","1",{"name":"description","content":"聚焦 Seedance2 引擎，为您提供全流程的 AI 创作体验。涵盖剧本智能拆解、分镜与资产生成、Seedance2 视频制作，打造极速、丝滑的电影级短剧制作与渲染体验。"}],["$","link","2",{"rel":"author","href":"https://art.doraart.com"}],["$","meta","3",{"name":"author","content":"doraArt Team"}],["$","meta","4",{"name":"keywords","content":"短剧制作,AI短剧,智能短剧制作,Seedance2引擎,剧本智能拆解,分镜生成,资产生成,AI视频制作,doraArt,AI电影,AI漫剧,短剧自动生成,AI剧本生成,AI角色生成,分镜视频,短剧平台,AI影视创作,Seedance,一键生成短剧,AIGC,智能影视制作,电影级短剧"}],["$","meta","5",{"name":"creator","content":"doraArt"}],["$","meta","6",{"name":"publisher","content":"doraArt"}],["$","meta","7",{"name":"robots","content":"index, follow"}],["$","meta","8",{"name":"googlebot","content":"index, follow, max-video-preview:-1, max-image-preview:large, max-snippet:-1"}],["$","link","9",{"rel":"canonical","href":"https://art.doraart.com"}],["$","meta","10",{"name":"format-detection","content":"telephone=no, address=no, email=no"}],["$","meta","11",{"property":"og:title","content":"一站式智能短剧制作平台 | doraArt Pro"}],["$","meta","12",{"property":"og:description","content":"聚焦 Seedance2 引擎，为您提供全流程的 AI 创作体验。剧本智能拆解、分镜与资产生成、Seedance2 视频制作。"}],["$","meta","13",{"property":"og:url","content":"https://art.doraart.com"}],["$","meta","14",{"property":"og:site_name","content":"doraArt Pro"}],["$","meta","15",{"property":"og:locale","content":"zh_CN"}],["$","meta","16",{"property":"og:image","content":"https://art.doraart.com/og-image.png"}],["$","meta","17",{"property":"og:image:width","content":"1200"}],["$","meta","18",{"property":"og:image:height","content":"630"}],["$","meta","19",{"property":"og:image:alt","content":"doraArt Pro - 一站式智能短剧制作平台"}],["$","meta","20",{"property":"og:type","content":"website"}],["$","meta","21",{"name":"twitter:card","content":"summary_large_image"}],["$","meta","22",{"name":"twitter:title","content":"一站式智能短剧制作平台 | doraArt Pro"}],["$","meta","23",{"name":"twitter:description","content":"聚焦 Seedance2 引擎，为您提供全流程的 AI 创作体验。剧本智能拆解、分镜与资产生成、Seedance2 视频制作。"}],["$","meta","24",{"name":"twitter:image","content":"https://art.doraart.com/og-image.png"}],["$","link","25",{"rel":"shortcut icon","href":"/favicon.ico"}],["$","link","26",{"rel":"icon","href":"/favicon.ico","type":"image/x-icon"}],["$","link","27",{"rel":"apple-touch-icon","href":"/favicon.ico"}],["$","$L13","28",{}]]
