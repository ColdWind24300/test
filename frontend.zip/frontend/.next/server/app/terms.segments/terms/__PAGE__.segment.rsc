1:"$Sreact.fragment"
2:I[74741,["/_next/static/chunks/0-a~.zjh.4es-.js","/_next/static/chunks/0yc4e27uxqth5.js","/_next/static/chunks/0565375x.yve~.js","/_next/static/chunks/0krq79ixq3i3-.js","/_next/static/chunks/0zu3am009s7rg.js","/_next/static/chunks/15z.m5r9geze6.js"],"LegalDocumentPage"]
3:I[90522,["/_next/static/chunks/0-a~.zjh.4es-.js","/_next/static/chunks/0yc4e27uxqth5.js","/_next/static/chunks/0565375x.yve~.js","/_next/static/chunks/0krq79ixq3i3-.js","/_next/static/chunks/0zu3am009s7rg.js"],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"rsc":["$","$1","c",{"children":[["$","$L2",null,{"type":"terms"}],[["$","script","script-0",{"src":"/_next/static/chunks/15z.m5r9geze6.js","async":true}]],["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"baAHqylI7dF6t6S3edqcE"}
5:null
