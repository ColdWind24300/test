1:"$Sreact.fragment"
2:I[98877,["/_next/static/chunks/0-a~.zjh.4es-.js","/_next/static/chunks/0yc4e27uxqth5.js","/_next/static/chunks/0565375x.yve~.js","/_next/static/chunks/0krq79ixq3i3-.js","/_next/static/chunks/0zu3am009s7rg.js"],"default"]
3:I[95566,["/_next/static/chunks/0-a~.zjh.4es-.js","/_next/static/chunks/0yc4e27uxqth5.js","/_next/static/chunks/0565375x.yve~.js","/_next/static/chunks/0krq79ixq3i3-.js","/_next/static/chunks/0zu3am009s7rg.js"],"default"]
0:{"rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"baAHqylI7dF6t6S3edqcE"}
