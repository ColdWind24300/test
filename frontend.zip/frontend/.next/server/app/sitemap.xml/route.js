var R=require("../../chunks/[turbopack]_runtime.js")("server/app/sitemap.xml/route.js")
R.c("server/chunks/[root-of-the-server]__0fglz8g._.js")
R.c("server/chunks/[root-of-the-server]__0gqq2tp._.js")
R.c("server/chunks/_next-internal_server_app_sitemap_xml_route_actions_036gxb_.js")
R.m(30619)
module.exports=R.m(30619).exports
