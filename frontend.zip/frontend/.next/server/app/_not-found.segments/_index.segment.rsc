1:"$Sreact.fragment"
2:I[97987,["/_next/static/chunks/0-a~.zjh.4es-.js","/_next/static/chunks/0yc4e27uxqth5.js","/_next/static/chunks/0565375x.yve~.js","/_next/static/chunks/0krq79ixq3i3-.js","/_next/static/chunks/0zu3am009s7rg.js"],""]
4:I[9975,["/_next/static/chunks/0-a~.zjh.4es-.js","/_next/static/chunks/0yc4e27uxqth5.js","/_next/static/chunks/0565375x.yve~.js","/_next/static/chunks/0krq79ixq3i3-.js","/_next/static/chunks/0zu3am009s7rg.js"],"I18nProvider"]
5:I[80809,["/_next/static/chunks/0-a~.zjh.4es-.js","/_next/static/chunks/0yc4e27uxqth5.js","/_next/static/chunks/0565375x.yve~.js","/_next/static/chunks/0krq79ixq3i3-.js","/_next/static/chunks/0zu3am009s7rg.js"],"ToastProvider"]
6:I[98877,["/_next/static/chunks/0-a~.zjh.4es-.js","/_next/static/chunks/0yc4e27uxqth5.js","/_next/static/chunks/0565375x.yve~.js","/_next/static/chunks/0krq79ixq3i3-.js","/_next/static/chunks/0zu3am009s7rg.js"],"default"]
7:I[95566,["/_next/static/chunks/0-a~.zjh.4es-.js","/_next/static/chunks/0yc4e27uxqth5.js","/_next/static/chunks/0565375x.yve~.js","/_next/static/chunks/0krq79ixq3i3-.js","/_next/static/chunks/0zu3am009s7rg.js"],"default"]
:HL["/_next/static/chunks/041cvacqxa3ip.css","style"]
3:T814,
(() => {
  if (typeof window === "undefined") return;

  const url = new URL(window.location.href);
  const ticket = url.searchParams.get("ticket");
  if (!ticket) return;

  const pendingKey = "__dora_ticket_login_pending__";
  const clearStoredAuth = () => {
    window.localStorage.removeItem("token");
    window.localStorage.removeItem("user");
  };

  window.sessionStorage.setItem(pendingKey, "1");

  const cleanTicketFromUrl = () => {
    url.searchParams.delete("ticket");
    return url.toString();
  };

  // ticket 登录优先于本地残留登录态，先清空再进行单点登录。
  clearStoredAuth();

  const apiBaseURL =
    (window.__DORA_RUNTIME_CONFIG__ && window.__DORA_RUNTIME_CONFIG__.NEXT_PUBLIC_API_URL) ||
    "http://localhost:6444/api/v1";

  fetch(apiBaseURL.replace(/\/$/, "") + "/login/ticket", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ ticket }),
  })
    .then(async (response) => {
      const result = await response.json().catch(() => null);
      if (!response.ok) {
        const message = result && (result.msg || result.message || result.error);
        throw new Error(message || "ticket login failed");
      }

      const payload = (result && result.data) || result;
      if (!payload || !payload.user || !payload.token) {
        throw new Error("ticket login payload is invalid");
      }

      const token =
        typeof payload.token === "string" ? payload.token : payload.token.access_token;
      if (!token) {
        throw new Error("access token missing");
      }

      window.localStorage.setItem("token", token);
      window.localStorage.setItem("user", JSON.stringify(payload.user));
      window.sessionStorage.removeItem(pendingKey);

      const nextUrl = cleanTicketFromUrl();
      if (url.pathname === "/login") {
        window.location.replace(url.origin + "/");
        return;
      }
      window.location.replace(nextUrl);
    })
    .catch(() => {
      window.sessionStorage.removeItem(pendingKey);
    });
})();
0:{"rsc":["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/041cvacqxa3ip.css","precedence":"next"}],["$","script","script-0",{"src":"/_next/static/chunks/0-a~.zjh.4es-.js","async":true}],["$","script","script-1",{"src":"/_next/static/chunks/0yc4e27uxqth5.js","async":true}],["$","script","script-2",{"src":"/_next/static/chunks/0565375x.yve~.js","async":true}],["$","script","script-3",{"src":"/_next/static/chunks/0krq79ixq3i3-.js","async":true}],["$","script","script-4",{"src":"/_next/static/chunks/0zu3am009s7rg.js","async":true}]],["$","html",null,{"lang":"zh-CN","children":["$","body",null,{"className":"h-screen overflow-hidden antialiased","children":[["$","$L2",null,{"src":"/config.js","strategy":"beforeInteractive"}],["$","$L2",null,{"id":"ticket-login-bootstrap","strategy":"beforeInteractive","dangerouslySetInnerHTML":{"__html":"$3"}}],["$","$L4",null,{"initialBrandConfig":{"brandName":"Dora Art","brandTitle":"Dora Art"},"children":["$","$L5",null,{"children":["$","div",null,{"className":"relative z-10 h-full min-h-0 overflow-hidden","children":["$","$L6",null,{"parallelRouterKey":"children","template":["$","$L7",null,{}],"notFound":[[["$","title",null,{"children":"404: This page could not be found."}],["$","div",null,{"style":{"fontFamily":"system-ui,\"Segoe UI\",Roboto,Helvetica,Arial,sans-serif,\"Apple Color Emoji\",\"Segoe UI Emoji\"","height":"100vh","textAlign":"center","display":"flex","flexDirection":"column","alignItems":"center","justifyContent":"center"},"children":["$","div",null,{"children":[["$","style",null,{"dangerouslySetInnerHTML":{"__html":"body{color:#000;background:#fff;margin:0}.next-error-h1{border-right:1px solid rgba(0,0,0,.3)}@media (prefers-color-scheme:dark){body{color:#fff;background:#000}.next-error-h1{border-right:1px solid rgba(255,255,255,.3)}}"}}],"$L8","$L9"]}]}]],[]]}]}]}]}]]}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"baAHqylI7dF6t6S3edqcE"}
8:["$","h1",null,{"className":"next-error-h1","style":{"display":"inline-block","margin":"0 20px 0 0","padding":"0 23px 0 0","fontSize":24,"fontWeight":500,"verticalAlign":"top","lineHeight":"49px"},"children":404}]
9:["$","div",null,{"style":{"display":"inline-block"},"children":["$","h2",null,{"style":{"fontSize":14,"fontWeight":400,"lineHeight":"49px","margin":0},"children":"This page could not be found."}]}]
