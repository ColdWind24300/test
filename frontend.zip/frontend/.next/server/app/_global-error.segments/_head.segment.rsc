1:"$Sreact.fragment"
2:I[90522,["/_next/static/chunks/0hqkv7pg6nbe~.js","/_next/static/chunks/0zu3am009s7rg.js"],"ViewportBoundary"]
3:I[90522,["/_next/static/chunks/0hqkv7pg6nbe~.js","/_next/static/chunks/0zu3am009s7rg.js"],"MetadataBoundary"]
4:"$Sreact.suspense"
0:{"rsc":["$","$1","h",{"children":[null,["$","$L2",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]}],["$","div",null,{"hidden":true,"children":["$","$L3",null,{"children":["$","$4",null,{"name":"Next.Metadata","children":[]}]}]}],null]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"baAHqylI7dF6t6S3edqcE"}
