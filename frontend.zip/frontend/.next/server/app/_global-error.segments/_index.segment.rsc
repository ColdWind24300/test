1:"$Sreact.fragment"
2:I[98877,["/_next/static/chunks/0hqkv7pg6nbe~.js","/_next/static/chunks/0zu3am009s7rg.js"],"default"]
3:I[95566,["/_next/static/chunks/0hqkv7pg6nbe~.js","/_next/static/chunks/0zu3am009s7rg.js"],"default"]
4:[]
0:{"rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"isPartial":false,"staleTime":300,"varyParams":"$W4","buildId":"baAHqylI7dF6t6S3edqcE"}
