var R=require("../../chunks/ssr/[turbopack]_runtime.js")("server/app/_global-error/page.js")
R.c("server/chunks/ssr/[root-of-the-server]__0~ze8b~._.js")
R.c("server/chunks/ssr/0r_m_next_dist_esm_build_templates_app-page_0c2c_68.js")
R.c("server/chunks/ssr/[root-of-the-server]__0ldavm3._.js")
R.c("server/chunks/ssr/0r_m_next_dist_0im~85s._.js")
R.c("server/chunks/ssr/0r_m_next_dist_client_components_builtin_global-error_0v~ypo4.js")
R.c("server/chunks/ssr/_next-internal_server_app__global-error_page_actions_0k77kol.js")
R.m(77740)
module.exports=R.m(77740).exports
