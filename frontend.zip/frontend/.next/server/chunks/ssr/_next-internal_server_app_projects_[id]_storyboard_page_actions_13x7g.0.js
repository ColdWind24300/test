module.exports=[46089,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_projects_%5Bid%5D_storyboard_page_actions_13x7g.0.js.map