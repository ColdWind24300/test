module.exports=[25435,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_projects_%5Bid%5D_resource_page_actions_12-kelf.js.map