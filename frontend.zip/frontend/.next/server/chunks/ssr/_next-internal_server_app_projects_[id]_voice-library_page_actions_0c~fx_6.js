module.exports=[45584,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_projects_%5Bid%5D_voice-library_page_actions_0c~fx_6.js.map