module.exports=[70775,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_projects_%5Bid%5D_human-library_page_actions_12drikn.js.map