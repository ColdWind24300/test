module.exports=[91760,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_projects_%5Bid%5D_canvas_page_actions_018o~75.js.map