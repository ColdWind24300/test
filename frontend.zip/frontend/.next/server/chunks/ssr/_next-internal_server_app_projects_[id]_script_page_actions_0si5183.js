module.exports=[79659,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_projects_%5Bid%5D_script_page_actions_0si5183.js.map