module.exports=[98585,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_projects_%5Bid%5D_timeline_page_actions_0-f5rj_.js.map