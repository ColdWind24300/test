module.exports=[79765,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_share_%5BshareCode%5D_page_actions_0atfptj.js.map