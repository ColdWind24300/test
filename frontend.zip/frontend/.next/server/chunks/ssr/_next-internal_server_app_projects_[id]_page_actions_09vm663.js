module.exports=[29657,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_projects_%5Bid%5D_page_actions_09vm663.js.map