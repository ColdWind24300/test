module.exports=[24868,(a,b,c)=>{b.exports=a.x("fs/promises",()=>require("fs/promises"))},42537,(a,b,c)=>{b.exports=a.x("vm",()=>require("vm"))},96342,69612,87359,34611,a=>{"use strict";var b=a.i(24868),c=a.i(14747);let d=a=>({brandName:a?.NEXT_BRAND_NAME?.trim()||"DoraArt Pro",brandTitle:a?.NEXT_BRAND_NAME?.trim()||"DORA ART PRO"}),e=a=>!!a?.NEXT_BRAND_NAME?.trim(),f=(a,b)=>a.replace(/\{\{\s*brandName\s*\}\}/g,b.brandName).replace(/\{\{\s*brandTitle\s*\}\}/g,b.brandTitle).replace(/DORA ART PRO/g,b.brandTitle).replace(/DoraArt Pro/g,b.brandName).replace(/doraArt Pro/g,b.brandName).replace(/DoraArt/g,b.brandName).replace(/doraArt/g,b.brandName);a.s(["applyBrandingToText",0,f,"hasRuntimeBrandOverride",0,e,"resolveBrandConfig",0,d],69612);let g={login:{registerBaseUrl:"https://www.doraart.com/register",backgroundVideoUrl:"https://doraart2.tos-cn-shanghai.volces.com/uploads/2026/04/28/2048941138202595328.mp4",brand:{primary:"DORA ART",secondary:"PRO"},metadata:{title:"登录 - DORA ART PRO | 智能短剧制作平台",description:"DORA ART PRO 是一款专业的智能短剧制作平台，聚焦 Seedance2 引擎。提供剧本拆解、角色场景道具提取、分镜设计、分镜图片及视频生成等全流程 AI 创作功能。",keywords:["短剧制作","AI短剧","剧本拆解","分镜生成","视频生成","Seedance2","角色提取","场景生成","DORA ART PRO"]}},home:{description:"在这里管理您的所有创作资产。您可以创建新的工作空间，或进入已有空间进行配置。"},layout:{metadata:{metadataBase:"https://art.doraart.com",title:"短剧制作 - 一站式智能短剧制作平台 | doraArt Pro",description:"聚焦 Seedance2 引擎，为您提供全流程的 AI 创作体验。涵盖剧本智能拆解、分镜与资产生成、Seedance2 视频制作，打造极速、丝滑的电影级短剧制作与渲染体验。",keywords:["短剧制作","AI短剧","智能短剧制作","Seedance2引擎","剧本智能拆解","分镜生成","资产生成","AI视频制作","doraArt","AI电影","AI漫剧","短剧自动生成","AI剧本生成","AI角色生成","分镜视频","短剧平台","AI影视创作","Seedance","一键生成短剧","AIGC","智能影视制作","电影级短剧"],authors:[{name:"doraArt Team",url:"https://art.doraart.com"}],creator:"doraArt",publisher:"doraArt",openGraph:{title:"一站式智能短剧制作平台 | doraArt Pro",description:"聚焦 Seedance2 引擎，为您提供全流程的 AI 创作体验。剧本智能拆解、分镜与资产生成、Seedance2 视频制作。",url:"https://art.doraart.com",siteName:"doraArt Pro",images:[{url:"https://art.doraart.com/og-image.png",width:1200,height:630,alt:"doraArt Pro - 一站式智能短剧制作平台"}],locale:"zh_CN",type:"website"},twitter:{card:"summary_large_image",title:"一站式智能短剧制作平台 | doraArt Pro",description:"聚焦 Seedance2 引擎，为您提供全流程的 AI 创作体验。剧本智能拆解、分镜与资产生成、Seedance2 视频制作。",images:["https://art.doraart.com/og-image.png"]},alternates:{canonical:"https://art.doraart.com"}}}},h=a=>a&&"object"==typeof a&&!Array.isArray(a)?a:{},i=(a,b)=>"string"==typeof a&&a.trim()?a:b,j=(a,b)=>Array.isArray(a)&&a.every(a=>"string"==typeof a)?a:b,k=a=>{let b,c,d,e,f=h(a),k=h(f.login),l=h(k.brand),m=h(k.metadata),n=h(f.home),o=h(f.layout),p=h(o.metadata),q=h(p.openGraph),r=h(p.twitter),s=h(p.alternates);return{login:{registerBaseUrl:i(k.registerBaseUrl,g.login.registerBaseUrl),backgroundVideoUrl:i(k.backgroundVideoUrl,g.login.backgroundVideoUrl),brand:{primary:i(l.primary,g.login.brand.primary),secondary:i(l.secondary,g.login.brand.secondary)},metadata:{title:i(m.title,g.login.metadata?.title||""),description:i(m.description,g.login.metadata?.description||""),keywords:j(m.keywords,g.login.metadata?.keywords||[])}},home:{description:i(n.description,g.home.description)},layout:{metadata:{metadataBase:i(p.metadataBase,g.layout.metadata.metadataBase),title:i(p.title,g.layout.metadata.title),description:i(p.description,g.layout.metadata.description),keywords:j(p.keywords,g.layout.metadata.keywords),authors:(b=p.authors,c=g.layout.metadata.authors,Array.isArray(b)&&b.every(a=>{let b=h(a);return"string"==typeof b.name&&"string"==typeof b.url})?b:c),creator:i(p.creator,g.layout.metadata.creator),publisher:i(p.publisher,g.layout.metadata.publisher),openGraph:{title:i(q.title,g.layout.metadata.openGraph.title),description:i(q.description,g.layout.metadata.openGraph.description),url:i(q.url,g.layout.metadata.openGraph.url),siteName:i(q.siteName,g.layout.metadata.openGraph.siteName),images:(d=q.images,e=g.layout.metadata.openGraph.images,Array.isArray(d)&&d.every(a=>{let b=h(a);return"string"==typeof b.url&&"number"==typeof b.width&&"number"==typeof b.height&&"string"==typeof b.alt})?d:e),locale:i(q.locale,g.layout.metadata.openGraph.locale),type:i(q.type,g.layout.metadata.openGraph.type)},twitter:{card:i(r.card,g.layout.metadata.twitter.card),title:i(r.title,g.layout.metadata.twitter.title),description:i(r.description,g.layout.metadata.twitter.description),images:j(r.images,g.layout.metadata.twitter.images)},alternates:{canonical:i(s.canonical,g.layout.metadata.alternates.canonical)}}}}};a.s(["defaultSiteConfig",0,g,"resolveRuntimeLoginConfig",0,(a,b)=>{let c=d(b),g=e(b),h=b?.NEXT_BRAND_NAME?.trim()||"";return{...a,registerBaseUrl:b?.NEXT_REGISTER_BASE_URL?.trim()||a.registerBaseUrl,backgroundVideoUrl:b?.NEXT_LOGIN_BACKGROUND_VIDEO_URL?.trim()||a.backgroundVideoUrl,brand:g?{primary:h||c.brandName,secondary:""}:a.brand,metadata:a.metadata?{title:f(a.metadata.title,c),description:f(a.metadata.description,c),keywords:a.metadata.keywords.map(a=>f(a,c))}:a.metadata}},"resolveSiteConfig",0,k],87359);let l=async()=>{try{let a=c.default.join(process.cwd(),"public","site-config.json"),d=await (0,b.readFile)(a,"utf-8");return k(JSON.parse(d))}catch{return g}};a.s(["loadSiteConfig",0,l],96342);var m=a.i(42537);let n=async()=>{try{let a=c.default.join(process.cwd(),"public","config.js"),d=await (0,b.readFile)(a,"utf-8"),e={window:{}};return m.default.runInNewContext(d,e),e.window.__DORA_RUNTIME_CONFIG__||{}}catch{return{}}};a.s(["loadRuntimeConfig",0,n],34611)},73684,(a,b,c)=>{let{createClientModuleProxy:d}=a.r(42701);a.n(d("[project]/node_modules/.pnpm/next@16.2.2_@babel+core@7.29.0_react-dom@19.2.4_react@19.2.4__react@19.2.4/node_modules/next/dist/client/script.js <module evaluation>"))},38478,(a,b,c)=>{let{createClientModuleProxy:d}=a.r(42701);a.n(d("[project]/node_modules/.pnpm/next@16.2.2_@babel+core@7.29.0_react-dom@19.2.4_react@19.2.4__react@19.2.4/node_modules/next/dist/client/script.js"))},85566,a=>{"use strict";a.i(73684);var b=a.i(38478);a.n(b)},40885,(a,b,c)=>{b.exports=a.r(85566)},47918,a=>{"use strict";a.s(["ToastProvider",()=>c,"useToast",()=>d]);var b=a.i(42701);let c=(0,b.registerClientReference)(function(){throw Error("Attempted to call ToastProvider() from the server but ToastProvider is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/components/ui/Toast.tsx <module evaluation>","ToastProvider"),d=(0,b.registerClientReference)(function(){throw Error("Attempted to call useToast() from the server but useToast is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/components/ui/Toast.tsx <module evaluation>","useToast")},96528,a=>{"use strict";a.s(["ToastProvider",()=>c,"useToast",()=>d]);var b=a.i(42701);let c=(0,b.registerClientReference)(function(){throw Error("Attempted to call ToastProvider() from the server but ToastProvider is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/components/ui/Toast.tsx","ToastProvider"),d=(0,b.registerClientReference)(function(){throw Error("Attempted to call useToast() from the server but useToast is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/components/ui/Toast.tsx","useToast")},48268,a=>{"use strict";a.i(47918);var b=a.i(96528);a.n(b)},24422,a=>{"use strict";a.s(["I18nProvider",()=>b]);let b=(0,a.i(42701).registerClientReference)(function(){throw Error("Attempted to call I18nProvider() from the server but I18nProvider is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/components/I18nProvider.tsx <module evaluation>","I18nProvider")},52266,a=>{"use strict";a.s(["I18nProvider",()=>b]);let b=(0,a.i(42701).registerClientReference)(function(){throw Error("Attempted to call I18nProvider() from the server but I18nProvider is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/components/I18nProvider.tsx","I18nProvider")},34946,a=>{"use strict";a.i(24422);var b=a.i(52266);a.n(b)},33290,a=>{"use strict";var b=a.i(21943),c=a.i(40885),d=a.i(48268),e=a.i(34946),f=a.i(96342),g=a.i(34611),h=a.i(69612);async function i(){let a=(await (0,f.loadSiteConfig)()).layout.metadata,b=a.openGraph.type,c=a.twitter.card;return{metadataBase:new URL(a.metadataBase),icons:{icon:[{url:"/favicon.ico",type:"image/x-icon"}],shortcut:["/favicon.ico"],apple:[{url:"/favicon.ico"}]},title:a.title,description:a.description,keywords:a.keywords,authors:a.authors,creator:a.creator,publisher:a.publisher,formatDetection:{email:!1,address:!1,telephone:!1},openGraph:{title:a.openGraph.title,description:a.openGraph.description,url:a.openGraph.url,siteName:a.openGraph.siteName,images:a.openGraph.images,locale:a.openGraph.locale,type:b},twitter:{card:c,title:a.twitter.title,description:a.twitter.description,images:a.twitter.images},robots:{index:!0,follow:!0,googleBot:{index:!0,follow:!0,"max-video-preview":-1,"max-image-preview":"large","max-snippet":-1}},alternates:{canonical:a.alternates.canonical}}}let j=`
(() => {
  if (typeof window === "undefined") return;

  const url = new URL(window.location.href);
  const ticket = url.searchParams.get("ticket");
  if (!ticket) return;

  const pendingKey = ${JSON.stringify("__dora_ticket_login_pending__")};
  const clearStoredAuth = () => {
    window.localStorage.removeItem("token");
    window.localStorage.removeItem("user");
  };

  window.sessionStorage.setItem(pendingKey, "1");

  const cleanTicketFromUrl = () => {
    url.searchParams.delete("ticket");
    return url.toString();
  };

  // ticket 登录优先于本地残留登录态，先清空再进行单点登录。
  clearStoredAuth();

  const apiBaseURL =
    (window.__DORA_RUNTIME_CONFIG__ && window.__DORA_RUNTIME_CONFIG__.NEXT_PUBLIC_API_URL) ||
    "http://localhost:6444/api/v1";

  fetch(apiBaseURL.replace(/\\/$/, "") + "/login/ticket", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ ticket }),
  })
    .then(async (response) => {
      const result = await response.json().catch(() => null);
      if (!response.ok) {
        const message = result && (result.msg || result.message || result.error);
        throw new Error(message || "ticket login failed");
      }

      const payload = (result && result.data) || result;
      if (!payload || !payload.user || !payload.token) {
        throw new Error("ticket login payload is invalid");
      }

      const token =
        typeof payload.token === "string" ? payload.token : payload.token.access_token;
      if (!token) {
        throw new Error("access token missing");
      }

      window.localStorage.setItem("token", token);
      window.localStorage.setItem("user", JSON.stringify(payload.user));
      window.sessionStorage.removeItem(pendingKey);

      const nextUrl = cleanTicketFromUrl();
      if (url.pathname === "/login") {
        window.location.replace(url.origin + "/");
        return;
      }
      window.location.replace(nextUrl);
    })
    .catch(() => {
      window.sessionStorage.removeItem(pendingKey);
    });
})();
`;async function k({children:a,runtimeConfigPromise:f}){let g=await f,i=(0,h.resolveBrandConfig)(g);return(0,b.jsx)("html",{lang:"zh-CN",children:(0,b.jsxs)("body",{className:"h-screen overflow-hidden antialiased",children:[(0,b.jsx)(c.default,{src:"/config.js",strategy:"beforeInteractive"}),(0,b.jsx)(c.default,{id:"ticket-login-bootstrap",strategy:"beforeInteractive",dangerouslySetInnerHTML:{__html:j}}),(0,b.jsx)(e.I18nProvider,{initialBrandConfig:i,children:(0,b.jsx)(d.ToastProvider,{children:(0,b.jsx)("div",{className:"relative z-10 h-full min-h-0 overflow-hidden",children:a})})})]})})}a.s(["default",0,function({children:a}){let[c]=[(0,g.loadRuntimeConfig)()];return(0,b.jsx)(k,{runtimeConfigPromise:c,children:a})},"generateMetadata",0,i])},70864,a=>{a.n(a.i(33290))}];

//# sourceMappingURL=%5Broot-of-the-server%5D__0_wsp1r._.js.map