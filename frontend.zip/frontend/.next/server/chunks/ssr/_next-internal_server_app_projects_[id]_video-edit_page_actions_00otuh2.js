module.exports=[29025,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_projects_%5Bid%5D_video-edit_page_actions_00otuh2.js.map